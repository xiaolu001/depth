import Render from './Render'
class AxisRender extends Render {
    constructor(viewPortHandler, dataProvider,interval) {
        super(viewPortHandler, dataProvider,interval)
    }
}
export default AxisRender