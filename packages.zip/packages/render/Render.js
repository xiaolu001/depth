class Render {
  constructor(viewPortHandler, dataProvider, interval) {
    this.viewPortHandler = viewPortHandler
    this.dataProvider = dataProvider
    this.interval = interval
  }
}

export default Render
